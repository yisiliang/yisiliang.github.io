Unmodified Redis source files referenced by the guide.
See SOURCE-MANIFEST.json for fixed commits and SHA-256 hashes.
See each baseline COPYING and file headers for licensing.
