package lab;

import java.lang.management.ClassLoadingMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

final class Metrics {
    private static final ClassLoadingMXBean CLASSES = ManagementFactory.getClassLoadingMXBean();
    private static final AtomicLong LAST_OPERATIONS = new AtomicLong(0);
    private static final long BEGIN = System.nanoTime();
    private static final long INIT_LOADED = CLASSES.getTotalLoadedClassCount();

    private Metrics() {}

    static void print(String label, long operations) {
        long delta = operations - LAST_OPERATIONS.getAndSet(operations);
        long loadedDelta = CLASSES.getTotalLoadedClassCount() - INIT_LOADED;
        long loadedNow = CLASSES.getLoadedClassCount();
        long unloaded = CLASSES.getUnloadedClassCount();
        double seconds = (System.nanoTime() - BEGIN) / 1_000_000_000.0;
        double heap = mb(ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed());
        double meta = 0, metaCommitted = 0;
        for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
            if ("Metaspace".equals(pool.getName())) {
                MemoryUsage usage = pool.getUsage();
                if (usage != null) {
                    meta = mb(usage.getUsed());
                    metaCommitted = mb(usage.getCommitted());
                }
            }
        }
        System.out.printf(Locale.US,
                "%s elapsed=%.1fs operations=%,d (+%,d since last) loadedDelta=%,d "
                + "loadedNow=%,d unloadedTotal=%,d metaspaceUsed=%.2fMB "
                + "metaspaceCommitted=%.2fMB heapUsed=%.2fMB%n",
                label, seconds, operations, delta, loadedDelta, loadedNow,
                unloaded, meta, metaCommitted, heap);
    }

    static String pid() {
        return ManagementFactory.getRuntimeMXBean().getName().split("@")[0];
    }

    private static double mb(long bytes) { return bytes / 1024.0 / 1024.0; }
}
