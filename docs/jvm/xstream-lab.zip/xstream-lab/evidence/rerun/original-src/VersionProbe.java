package lab;

import com.thoughtworks.xstream.XStream;

/**
 * 跨 XStream 版本探针：纯 POJO + 每次 new XStream()，看是否每次请求都会加载/定义新类。
 *
 * 编译时按项目依赖（1.4.20）编译，但安全框架相关 API 全部用反射调用，
 * 因此可以用 lasspath 换成任意历史版本的 xstream jar 直接运行（必须用 target/classes，不能用 shaded 包）。
 */
public final class VersionProbe {

    private static final String XML = "<order><id>10001</id><amount>128</amount>"
            + "<customer><name>Alice</name></customer></order>";

    public static final class Order {
        public String id;
        public int amount;
        public Customer customer;
    }

    public static final class Customer {
        public String name;
    }

    /** 没有无参构造器的 POJO（企业项目里极常见）：XStream 无法用 type.newInstance()，
     *  必须回退到 ReflectionFactory.newConstructorForSerialization() 或 Unsafe。 */
    public static final class Strict {
        public String id;
        public int amount;

        public Strict(String id, int amount) {
            this.id = id;
            this.amount = amount;
        }
    }

    private static final String STRICT_XML = "<strict><id>10001</id><amount>128</amount></strict>";

    private static XStream createStrict() {
        XStream x = new XStream();
        relax(x, Strict.class);
        x.alias("strict", Strict.class);
        return x;
    }

    private static final class StrictShared {
        static final XStream XSTREAM = createStrict();
    }

    private static XStream create() {
        XStream x = new XStream();
        relax(x);
        x.alias("order", Order.class);
        x.alias("customer", Customer.class);
        return x;
    }

    private static final class Shared {
        static final XStream XSTREAM = create();
    }

    /** 1.4.7+ 有安全框架；更老的版本没有 allowTypes，直接跳过。 */
    private static void relax(XStream x) {
        relax(x, Order.class);
    }

    private static void relax(XStream x, Class<?> extra) {
        Class<?>[] types = extra == Order.class
                ? new Class<?>[] {Order.class, Customer.class}
                : new Class<?>[] {extra};
        try {
            XStream.class.getMethod("allowTypes", Class[].class).invoke(x, (Object) types);
        } catch (Throwable ignore) {
            // API 不存在（<1.4.7）或参数不匹配：忽略
        }
        try {
            Object any = Class.forName("com.thoughtworks.xstream.security.AnyTypePermission")
                    .getField("ANY").get(null);
            XStream.class.getMethod("addPermission", Class.forName("com.thoughtworks.xstream.security.TypePermission"))
                    .invoke(x, any);
        } catch (Throwable ignore) {
            // 同上
        }
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "new";
        int loops = args.length > 1 ? Integer.parseInt(args[1]) : 300;
        String ver;
        try {
            ver = String.valueOf(XStream.class.getPackage().getImplementationVersion());
        } catch (Throwable t) {
            ver = "?";
        }
        System.out.println("xstream-impl-version=" + ver + " mode=" + mode + " loops=" + loops);

        if ("rf".equals(mode)) {
            rfProbe(loops);
            return;
        }

        boolean strict = mode.startsWith("strict-");
        String base = strict ? mode.substring("strict-".length()) : mode;
        Shared.XSTREAM.getClass();
        StrictShared.XSTREAM.getClass();
        Metrics.print("START", 0);
        long checksum = 0;
        for (int i = 0; i < loops; i++) {
            XStream x = "static".equals(base)
                    ? (strict ? StrictShared.XSTREAM : Shared.XSTREAM)
                    : (strict ? createStrict() : create());
            if (strict) {
                Strict o = (Strict) x.fromXML(STRICT_XML);
                if (!"10001".equals(o.id) || o.amount != 128) {
                    throw new IllegalStateException("bad result");
                }
                checksum += o.amount;
            } else {
                Order o = (Order) x.fromXML(XML);
                if (!"10001".equals(o.id) || o.amount != 128 || !"Alice".equals(o.customer.name)) {
                    throw new IllegalStateException("bad result");
                }
                checksum += o.amount;
            }
        }
        Metrics.print("DONE ", loops);
        System.out.println("checksum=" + checksum + " (should be " + (loops * 128L) + ")");
    }

    /** 直接探测 JDK 8 的 ReflectionFactory：每次调用是否都会定义一个新的 accessor 类？ */
    private static void rfProbe(int loops) throws Exception {
        sun.reflect.ReflectionFactory rf = sun.reflect.ReflectionFactory.getReflectionFactory();
        java.lang.reflect.Constructor<?> objCtor = Object.class.getDeclaredConstructor();
        Metrics.print("START", 0);
        Object last = null;
        for (int i = 0; i < loops; i++) {
            java.lang.reflect.Constructor<?> c = rf.newConstructorForSerialization(Strict.class, objCtor);
            last = c.newInstance();
        }
        System.out.println("lastInstance=" + (last != null));
        Metrics.print("DONE ", loops);
    }
}
