package lab;

import com.thoughtworks.xstream.XStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 实验四：老版本 XStream（1.2.x / 1.3.x）的 Sun14ReflectionProvider + 每次 new XStream()。
 *
 * 机制（已用字节码 + 源码确认）：
 * 1. XStream 1.2.2 / 1.3.1 的 Sun14ReflectionProvider.newInstance() 对**每个类**都调用
 *    ReflectionFactory.newConstructorForSerialization(type, Object.<init>)，
 *    结果缓存在 **实例字段** constructorCache（1.2.2 是 HashMap，1.3.1 是 WeakHashMap）里。
 * 2. JDK 8 的 newConstructorForSerialization() 没有跨调用缓存：**每次调用都会生成并定义
 *    一个新的 sun.reflect.GeneratedSerializationConstructorAccessor 类**（实测 500 次调用 = 500 个类）。
 * 3. 于是「每次请求 new XStream()」= 每次请求一份空 constructorCache = 每次请求生成新类；
 *    复用 static XStream 则缓存命中，每个类最多生成一次。
 * 4. 该 provider 只在 canUseSun14ReflectionProvider() 成立时被选中：
 *    java.vm.vendor 含 Sun/Apple/IBM/HP/Blackdown/BEA/Hitachi 且 JDK>=1.4 且能加载 sun.misc.Unsafe。
 *    Oracle/Corretto/Zulu 的 vendor 不匹配，因此本实验显式设置 vendor 来复现当年的环境。
 * 5. XStream 1.4.5 起已移除该路径（改用 Unsafe.allocateInstance），不再有这个问题。
 */
public final class LegacyProviderBench {

    private static final String XML = "<order><id>10001</id><amount>128</amount></order>";

    public static final class Order {
        public String id;
        public int amount;
    }

    private static XStream create() {
        XStream x = new XStream();
        relax(x); // 1.4.7+ 需要显式放行；更老的版本没有安全框架，反射调用会静默跳过
        x.alias("order", Order.class);
        return x;
    }

    private static void relax(XStream x) {
        try {
            XStream.class.getMethod("allowTypes", Class[].class)
                    .invoke(x, (Object) new Class<?>[] {Order.class});
        } catch (Throwable ignore) {
            // API 不存在（<1.4.7）：忽略
        }
    }

    private static final class Shared {
        static final XStream XSTREAM = create();
    }

    /** 模拟真实业务把 XStream 实例长期持有（缓存 / ThreadLocal / 连接池内字段）：
     *  持有实例 = 持有它的 constructorCache = 持有生成的 accessor 类，永不可卸载。 */
    private static final List<XStream> RETAINED = java.util.Collections.synchronizedList(new ArrayList<XStream>());

    private static String providerName(XStream x) {
        try {
            Method m = XStream.class.getMethod("getReflectionProvider");
            return m.invoke(x).getClass().getName();
        } catch (Throwable t) {
            return "(unknown: " + t.getClass().getSimpleName() + ")";
        }
    }

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "new";
        int threads = args.length > 1 ? Integer.parseInt(args[1]) : 8;
        int loopsPerThread = args.length > 2 ? Integer.parseInt(args[2]) : 500;
        boolean retain = mode.endsWith("-retain");
        final String base = retain ? mode.substring(0, mode.length() - "-retain".length()) : mode;
        if (!("new".equals(base) || "static".equals(base))) {
            System.err.println("Usage: java -cp xstream-metaspace-lab-1.0.0.jar lab.LegacyProviderBench "
                    + "[new|static][-retain] [threads] [loops]");
            System.exit(2);
        }
        final boolean keep = retain;

        // 复现「Sun/Oracle OEM JDK」环境：老版本 XStream 用 vendor 字符串决定 ReflectionProvider。
        // XStream 1.4.4 有 isOracle()，因此在标准 Oracle JDK 8（java.vm.vendor="Oracle Corporation"）上就会选中
        // 带实例级 constructorCache 的 Sun14ReflectionProvider。1.4.5 起厂商判断被整个移除。
        String vendor = System.getProperty("java.vm.vendor");
        String spoof = System.getProperty("legacy.bench.vendor", "Sun Microsystems Inc.");
        if (vendor != null && vendor.indexOf("Sun") < 0
                && !Boolean.getBoolean("legacy.bench.keep.vendor")) {
            System.setProperty("java.vm.vendor", spoof);
            System.out.println("NOTE: java.vm.vendor spoofed '" + vendor + "' -> '" + spoof
                    + "' to reproduce the legacy Sun14ReflectionProvider selection");
        }

        final XStream shared = "static".equals(base) ? Shared.XSTREAM : null;
        System.out.println("PID=" + Metrics.pid() + " Java=" + System.getProperty("java.version")
                + " mode=" + mode + " threads=" + threads + " loopsPerThread=" + loopsPerThread
                + " provider=" + providerName(Shared.XSTREAM));

        final AtomicLong operations = new AtomicLong();
        final CountDownLatch ready = new CountDownLatch(threads);
        final CountDownLatch start = new CountDownLatch(1);
        ExecutorService workers = Executors.newFixedThreadPool(threads);
        ScheduledExecutorService monitor = Executors.newSingleThreadScheduledExecutor();
        List<Future<Long>> results = new ArrayList<Future<Long>>();
        Metrics.print("START", 0);
        monitor.scheduleAtFixedRate(new Runnable() {
            @Override public void run() { Metrics.print("TICK ", operations.get()); }
        }, 2, 2, TimeUnit.SECONDS);

        try {
            for (int t = 0; t < threads; t++) {
                results.add(workers.submit(new Callable<Long>() {
                    @Override public Long call() throws Exception {
                        ready.countDown();
                        start.await();
                        long checksum = 0;
                        for (int i = 0; i < loopsPerThread; i++) {
                            XStream x = shared != null ? shared : create();
                            if (keep) {
                                RETAINED.add(x); // 故意保留实例，使其生成的类无法卸载
                            }
                            Order o = (Order) x.fromXML(XML);
                            if (!"10001".equals(o.id) || o.amount != 128) {
                                throw new IllegalStateException("bad result");
                            }
                            checksum += o.amount;
                            operations.incrementAndGet();
                        }
                        return checksum;
                    }
                }));
            }
            ready.await();
            start.countDown();
            long checksum = 0;
            for (Future<Long> result : results) checksum += result.get();
            Metrics.print("DONE ", operations.get());
            System.out.println("retainedXStreams=" + RETAINED.size());
            System.out.println("checksum=" + checksum + " (should be " + ((long) threads * loopsPerThread * 128) + ")");
        } finally {
            start.countDown();
            monitor.shutdownNow();
            workers.shutdownNow();
        }
    }
}
