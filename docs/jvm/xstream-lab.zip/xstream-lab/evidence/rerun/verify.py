from pathlib import Path
import subprocess,concurrent.futures,json,re,collections,hashlib
p=Path('/tmp/xstream-review-20261008'); j=Path('/Users/yisiliang/Library/Java/JavaVirtualMachines/corretto-1.8.0_462/Contents/Home/bin'); src=Path('/Users/yisiliang/Downloads/xstream-metaspace-lab/src/main/java/lab'); m=Path.home()/'.m2/repository'
jar=lambda v:str(m/f'com/thoughtworks/xstream/xstream/{v}/xstream-{v}.jar')
deps=':'.join(str(m/s) for s in ['xpp3/xpp3_min/1.1.4c/xpp3_min-1.1.4c.jar','xmlpull/xmlpull/1.1.3.1/xmlpull-1.1.3.1.jar'])
(p/'classes').mkdir(exist_ok=True)
subprocess.run([str(j/'javac'),'-cp',jar('1.4.4'),'-d',str(p/'classes')]+[str(src/f'{n}.java') for n in ['LegacyProviderBench','Metrics','VersionProbe']],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
cases=[('new-trace','1.4.4',['-XX:+TraceClassLoading'],['new','1','1000']),('static-trace','1.4.4',['-XX:+TraceClassLoading'],['static','1','1000']),('new-gc','1.4.4',['-Xms1g','-Xmx1g','-XX:+UseParallelGC','-XX:+PrintGCDetails','-XX:+PrintGCApplicationStoppedTime',f'-Xloggc:{p}/new-gc.log'],['new','4','50000']),('static-gc','1.4.4',['-Xms1g','-Xmx1g','-XX:+UseParallelGC','-XX:+PrintGCDetails','-XX:+PrintGCApplicationStoppedTime',f'-Xloggc:{p}/static-gc.log'],['static','4','50000']),('upgrade-trace','1.4.5',['-XX:+TraceClassLoading'],['new','1','1000']),('native-vendor-trace','1.4.4',['-XX:+TraceClassLoading','-Dlegacy.bench.keep.vendor=true'],['new','1','1000']),('rf-trace','1.4.4',['-XX:+TraceClassLoading'],['rf','500'])]
def run(c):
 name,v,flags,args=c; cmd=[str(j/'java')]+flags+['-Dlegacy.bench.vendor=Oracle Corporation','-cp',f'{p}/classes:{jar(v)}:{deps}','lab.VersionProbe' if name=='rf-trace' else 'lab.LegacyProviderBench']+args
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90); (p/f'{name}.log').write_text(r.stdout)
 log=(p/f'{name}.log').read_text(); g=log
 if name in ['new-gc','static-gc']: g=(p/f'{name}.log').read_text(); (p/f'{name}-app.log').write_text(log)
 # -Xloggc output shares the app filename; use distinct app output files to avoid overwriting.
 return {'name':name,'returncode':r.returncode,'command':cmd,'generated_accessors':len(re.findall(r'^\[Loaded sun\.reflect\.GeneratedSerializationConstructorAccessor\d+ ',log,re.M)),'provider':re.findall(r'provider=(\S+)',log),'done':next((s for s in log.splitlines() if s.startswith('DONE')),''),'checksum':next((s for s in log.splitlines() if s.startswith('checksum')),'')}
# Fix the GC destination before runs, preserving application output separately.
for c in cases:
 if c[0] in ['new-gc','static-gc']:
  c[2][-1]=f'-Xloggc:{p}/{c[0]}-events.log'
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex: results=list(ex.map(run,cases))
for r in results:
 if r['name'] in ['new-gc','static-gc']:
  g=(p/f"{r['name']}-events.log").read_text(); r['gc_causes']=dict(collections.Counter(re.findall(r'(?:Full )?GC \([^)]*\)',g)));r['application_stopped_seconds']=sum(map(float,re.findall(r'Total time for which application threads were stopped: ([0-9.]+)',g)))
(p/'rerun-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
