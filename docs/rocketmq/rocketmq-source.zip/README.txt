Unmodified Apache RocketMQ source files referenced by the guide.
See SOURCE-MANIFEST.json for fixed commits and SHA-256 hashes.
See each baseline LICENSE, NOTICE and file headers for licensing.
