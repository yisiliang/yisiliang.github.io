Unmodified OpenJDK8u source files referenced by this reading guide.
See SOURCE-MANIFEST.json for exact paths, commit and SHA-256 hashes.
See LICENSE and each file header for upstream copyright and licensing.
